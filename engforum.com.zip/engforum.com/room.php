<?php require_once 'assets/core/init.php'; ?>
<?php
    if (!loggedIn()) {
        $session->message("<script>alert('You must be logged in');</script>"); 
        redirectTo('index.php?chat');
    }

    $user_id = (int)$_SESSION['us3rid'];
    $userInfo = $profile->getInfo($user_id);
    $userPro = $profile->getUserProfile($user_id);
    $field = explode(' ', $userInfo['field']);
    $room = strtolower($field[0]);
    $group_id = intval($_GET['room']);
    $roomMessages = !empty($roomC->getMessages($group_id)) ? $roomC->getMessages($group_id) : [];
    
    if ($_GET['name'] != $room) {
        $session->message("<h3 class='text-danger'>You can't join this room because its not your field</h3>"); 
        redirectTo('index.php');
    }
?>
<?php include_once 'assets/inc/header.php'; ?>

<?php include_once 'assets/inc/navigation.php'; ?>

<!-- Page Content -->
<div class="container" style="margin-bottom: 10px">
    <div class="row mt-3">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="panel panel-primary">
                <div class="panel-heading"><h3 class="text-center"><?php echo $field[0] . ' Engineering Chat Room'; ?></h3></div>
            </div>
            <div class="panel-body bg-white">
                <div id="chatArea" class="p-2" style="overflow-y: scroll; height: 400px;">
                    <?php foreach ($roomMessages as $msg): ?>
                        <?php if ($msg['id'] == $user_id): ?>
                            <div class="alert alert-success" style="display: block;">
                                <?php echo $msg['message'] . '<br>'; ?>
                                <small><?php echo datetime_to_text($msg['send_date']) . '<br>'; ?></small>
                            </div><br>
                        <?php else: ?>
                            <div class="alert alert-info text-right pull-right" style="display: block;"> 
                                <strong><?php echo $profile->getUserProfile($msg['id'])['firstName']; ?></strong><hr>
                                <?php echo $msg['message'] . '<br>';  ?>
                                <small><?php echo datetime_to_text($msg['send_date']) . '<br>'; ?></small>
                            </div><br><br><br><br><br><br><br>
                        <?php endif; ?>
                    <?php endforeach ?>
                </div><br>
                <input type="hidden" name="group_id" id="group_id" value="<?php echo $group_id; ?>">
                <textarea name="message" id="message" cols="30" rows="3" class="form-control" placeholder="Type your message..."></textarea>
            </div>
            <div class="panel-footer">
                <button class="btn btn-outline-primary" onclick="send_message();" style="margin-left: 89%">Send <i class="fa fa-send"></i></button>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
    <!-- /.row -->

</div>
<!-- /.container -->
<?php include_once 'assets/inc/footer.php'; ?>

<script>
    function send_message() {
        let message = $('#message').val();
        let group_id = $('#group_id').val();
        if(message.length === 0) {
            alert('Provide a message to send!');
        } else {
            $.ajax({
                url: 'assets/asyn/room_chat.php',
                method: 'POST',
                data: {msg: message, group_id: group_id},
                cache: false,
                success: function () {
                    $('#chatArea').val('');
                    get_messages(group_id);
                    $('#message').val('');
                }
            });
        }
    }

    function get_messages(group_id) {
        let data = {group_id: group_id};
        $.ajax({
            url: 'assets/asyn/get_room_messages.php',
            method: 'POST',
            data: data,
            cache: false,
            success: function (data) {
                $('#chatArea').html(data);
            }
        });
        $('#chatArea').animate({scrollTop: $('#chatArea')[0].scrollHeight}, 1000);
    }

    function boot_chat() {
        let group_id = $('#group_id').val();
        let chatArea = $('#message');
        setInterval(get_messages, 2000, group_id);

        chatArea.bind('keydown', function (event) {
            if (event.keyCode === 13 && event.shiftKey === false) {
                let message = chatArea.val();

                if (message.length !== 0) {
                    send_message(message);
                    event.preventDefault();
                } else {
                    alert('Provide a message to send!');
                    chatArea.val('');
                }
            }
        })
    }

    boot_chat();
</script>
