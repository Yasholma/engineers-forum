<?php require_once 'assets/core/init.php'; ?>
<?php
    if (!loggedIn()) {
        $session->message("<script>alert('You must be logged in');</script>"); 
        redirectTo('index.php?chat');
    }
    $sId = (int)$_SESSION['us3rid'];
    $rId = (int)$_GET['rId'];
    $pMessages = !empty($pchat->getMessages($sId, $rId)) ? $pchat->getMessages($sId, $rId) : [];
?>
<?php include_once 'assets/inc/header.php'; ?>

<?php include_once 'assets/inc/navigation.php'; ?>

<div class="container" style="margin-bottom: 10px">
    <div class="row mt-3">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="panel panel-success">
                <div class="panel-heading text-center"><h4><?php echo $profile->getUserProfile($rId)['firstName']; ?></h4></div>
            </div>
            <div class="panel-body bg-white">
                <div id="chatArea" class="p-2" style="overflow-y: scroll; height: 400px;">
                    <?php foreach ($pMessages as $msg): ?>
                        <?php if ($msg['sId'] == $sId): ?>
                            <div class="alert alert-success" style="display: block;">
                                <?php echo $msg['message'] . '<br>'; ?>
                                <small><?php echo datetime_to_text($msg['timestamp']) . '<br>'; ?></small>
                            </div><br>
                        <?php else: ?>
                            <div class="alert alert-info text-right pull-right" style="display: block;"> 
                                <strong><?php echo $profile->getUserProfile($msg['sId'])['firstName']; ?></strong><hr>
                                <?php echo $msg['message'] . '<br>';  ?>
                                <small><?php echo datetime_to_text($msg['timestamp']) . '<br>'; ?></small>
                            </div><br><br><br><br><br><br><br>
                        <?php endif; ?>
                    <?php endforeach ?>
                </div><br>
                <textarea name="message" id="message" cols="30" rows="3" class="form-control" placeholder="Type your message..."></textarea>
                <input type="hidden" name="sId" id="sId" value="<?php echo $sId; ?>">
                <input type="hidden" name="rId" id="rId" value="<?php echo $rId; ?>">
            </div>
            <div class="panel-footer hidden-xs">
                <button class="btn btn-outline-primary" onclick="send_message();" style="margin-left: 89%">Send <i class="fa fa-send"></i></button>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
    <!-- /.row -->

</div>
<?php include_once 'assets/inc/footer.php'; ?>
<script>
    function send_message() {
        let message = $('#message').val();
        let sId = $('#sId').val();
        let rId = $('#rId').val();

        let data = {'sId': sId, 'rId': rId, 'msg': message};

        if(message.length === 0) {
            alert('Provide a message to send!');
        } else {
            $.ajax({
                url: 'assets/asyn/add_private_msg.php',
                method: 'POST',
                data: data,
                cache: false,
                success: function (data) {
                    $('#chatArea').val('');
                    get_messages(sId, rId);
                    $('#message').val('');
                }
            });
        }
    }

    function get_messages(sId, rId) {
        let data = {sId: sId, rId: rId};
        $.ajax({
            url: 'assets/asyn/get_private_messages.php',
            method: 'GET',
            data: data,
            cache: false,
            success: function (data) {
                $('#chatArea').html(data);
            }
        });
        $('#chatArea').animate({
                            scrollTop: $('#chatArea')[0].scrollHeight
                            }, 1000);
    }

    function boot_chat() {
        let chatArea = $('#message');
        let sId = $('#sId').val();
        let rId = $('#rId').val();
        setInterval(get_messages, 2000, sId, rId);

        chatArea.bind('keydown', function (event) {
            if (event.keyCode === 13 && event.shiftKey === false) {
                let message = chatArea.val();

                if (message.length !== 0) {
                    send_message(message);
                    event.preventDefault();
                } else {
                    alert('Provide a message to send!');
                    chatArea.val('');
                }
            }
        })
    }

    boot_chat();
</script>
