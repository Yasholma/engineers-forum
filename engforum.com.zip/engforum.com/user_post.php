<?php require_once 'assets/core/init.php'; ?>
<?php
  $user_id = (int)urlencode($_GET['user_id']);
  $user = $profile->getUserProfile($user_id);
 ?>
<?php include_once 'assets/inc/header.php'; ?>

    <?php include_once 'assets/inc/navigation.php'; ?>

    <!-- Page Content -->
    <div class="container">
      <div class="row">
        <!-- Blog Entries Column -->
        <div class="col-md-8 pt-1">
          <div class="row">
            <div class="col-md-12">
              <h1 class="my-4" id="all-post-header">All Posts by <?php echo $user['firstName'] .' '. $user['middeName'] .' '. $user['lastName']; ?></h1>
              <?php if (loggedIn()): ?>
                <a href="./" class="btn btn-outline-secondary pull-right mt-4"><i class="fa fa-home"></i></a>
              <?php endif ?>
            </div>
          </div>

          <!-- Blog Post -->
          <?php $allPost = $post->getPostByUser($user_id); ?>
          <?php foreach ($allPost as $post): ?>
            <div class="card mb-2">
              <div class="card-body">
                <h2 class="card-title"><?php echo $post['title']; ?></h2>
                <p class="card-text"><?php echo excerpt($post['body'], 15); ?></p>
                <a href="post.php?id=<?php echo $post['id']; ?>" class="btn btn-outline-primary pull-right">Read More &rarr;</a>
              </div>
              <div class="card-footer text-muted">
                Posted on <?php echo datetime_to_text($post['created_at']); ?>
              </div>
            </div>
          <?php endforeach ?>

          <!-- Pagination -->

        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4 mt-4">
          <?php if (!loggedIn()): ?>
            <form action="#" id="login-form" class="border-primary" method="post">
              <div class="form-group">
                <input type="email" name="email" id="email" class="form-control" placeholder="Email" style="margin-top: -10px;">
              </div>
              <div class="form-group" style="margin-top: -10px;">
                <input type="password" name="password" id="password" class="form-control" placeholder="Password">
              </div>
              <input type="checkbox" name="remember_me" id="remember_me"><label for="remember_me">&nbsp;Remember me?</label>
              <div class="form-group">
                <button class="btn btn-primary" name="login_btn" style="margin-left: 81%;">Login</button>
              </div>
            </form>
          <?php endif ?>
          <!-- Search Widget -->
          <?php include_once 'assets/inc/widgets/search.php'; ?>

          <!-- Categories Widget -->
          <?php include_once 'assets/inc/widgets/categories.php'; ?>

          <!-- Side Widget -->
          <?php include_once 'assets/inc/widgets/latest_post.php'; ?>

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php include_once 'assets/inc/footer.php'; ?>
