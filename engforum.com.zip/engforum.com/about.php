<?php require_once 'assets/core/init.php'; ?>
<?php

 ?>
<?php include_once 'assets/inc/header.php'; ?>

    <?php include_once 'assets/inc/navigation.php'; ?>

    <!-- Page Content -->
    <div class="container">
      <div class="row">
        <!-- Blog Entries Column -->
        <div class="col-md-8 pt-1">
          <?php success($session->message()); ?>
          <?php error($errors); ?>
          <div class="row">
            <div class="col-md-12">
              <h1 class="my-4" id="all-post-header">About Engineer's Forum</h1><br>
            </div>
          </div>
    
        <!-- About Us Part -->
        <div class="bg-white" style="padding: 10px; border-radius: 5px;">
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero veniam nam quod, laudantium blanditiis aliquam maiores nisi, voluptatem, obcaecati magnam nihil nobis dignissimos fuga praesentium sed fugiat assumenda rerum optio veritatis ad asperiores unde dicta error. Adipisci itaque commodi quos, iste iusto nesciunt voluptates earum molestias mollitia provident recusandae atque?</p>
        </div>


        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4 mt-4">
          <!-- Search Widget -->
          <?php include_once 'assets/inc/widgets/search.php'; ?>

            <!-- Side Widget -->
            <?php include_once 'assets/inc/widgets/latest_post.php'; ?>

            <!-- Categories Widget -->
            <?php include_once 'assets/inc/widgets/categories.php'; ?>


        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php include_once 'assets/inc/footer.php'; ?>
