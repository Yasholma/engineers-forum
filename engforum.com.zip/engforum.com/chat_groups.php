<?php require_once 'assets/core/init.php'; ?>
<?php
    if (!loggedIn()) {
        $session->message("<script>alert('You must be logged in');</script>"); 
        redirectTo('index.php?chat');
    }
    $user_id = (int)$_GET['id'];
    $chatMessages = !empty($chat->getMessages()) ? $chat->getMessages() : [];
    $userInfo = $profile->getUserProfile($user_id);
?>
<?php include_once 'assets/inc/header.php'; ?>

<?php include_once 'assets/inc/navigation.php'; ?>

<!-- Page Content -->
<div class="container" style="margin-bottom: 10px">
    <div class="row mt-3">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="panel panel-primary">
                <div class="panel-heading"><?php echo $userInfo['firstName']; ?></div>
            </div>
            <div class="panel-body bg-white">
                <div id="chatArea" class="p-2" style="overflow-y: scroll; height: 400px;">
                    <?php foreach ($chatMessages as $msg): ?>
                        <?php if ($msg['id'] == $user_id): ?>
                            <div class="alert alert-success" style="display: block;">
                                <?php echo $msg['message'] . '<br>'; ?>
                                <small><?php echo datetime_to_text($msg['send_date']) . '<br>'; ?></small>
                            </div><br>
                        <?php else: ?>
                            <div class="alert alert-info text-right pull-right" style="display: block;"> 
                                <strong><?php echo $profile->getUserProfile($msg['id'])['firstName']; ?></strong><hr>
                                <?php echo $msg['message'] . '<br>';  ?>
                                <small><?php echo datetime_to_text($msg['send_date']) . '<br>'; ?></small>
                            </div><br><br><br><br><br><br><br>
                        <?php endif; ?>
                    <?php endforeach ?>
                </div><br>
                <textarea name="message" id="message" cols="30" rows="3" class="form-control" placeholder="Type your message..."></textarea>
            </div>
            <div class="panel-footer">
                <button class="btn btn-outline-primary" onclick="send_message();" style="margin-left: 89%">Send <i class="fa fa-send"></i></button>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
    <!-- /.row -->

</div>
<!-- /.container -->
<?php include_once 'assets/inc/footer.php'; ?>

<script>
    function send_message() {
        let message = $('#message').val();
        if(message.length === 0) {
            alert('Provide a message to send!');
        } else {
            $.ajax({
                url: 'assets/asyn/add_msg.php',
                method: 'POST',
                data: {msg: message},
                cache: false,
                success: function (data) {
                    $('#chatArea').val('');
                    get_messages();
                    $('#message').val('');
                }
            });
        }
    }

    function get_messages() {
        $.ajax({
            url: 'assets/asyn/get_messages.php',
            method: 'GET',
            cache: false,
            success: function (data) {
                $('#chatArea').html(data);
            }
        });
        $('#chatArea').animate({
        					scrollTop: $('#chatArea')[0].scrollHeight
        					}, 1000);
    }

    function boot_chat() {
        let chatArea = $('#message');
        setInterval(get_messages, 2000);

        chatArea.bind('keydown', function (event) {
            if (event.keyCode === 13 && event.shiftKey === false) {
                let message = chatArea.val();

                if (message.length !== 0) {
                    send_message(message);
                    event.preventDefault();
                } else {
                    alert('Provide a message to send!');
                    chatArea.val('');
                }
            }
        })
    }

    boot_chat();
</script>
