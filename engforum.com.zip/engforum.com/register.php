<?php require_once 'assets/core/init.php'; ?>
<?php 
	if (loggedIn()) {
	    redirectTo('index.php');
	  }
	// Getting data from classes
	$allStates = $state->getStates();

	// Registration Form Validation
	if (isset($_POST['register_btn'])) {

		// All Required Fields array
		$required = ['email', 'password', 'confirm_password', 'firstName', 'lastName', 'phone', 'gender', 'state_id', 'lga_id', 'dob', 'address'];

		// Loop through form collection to find required fields
	    foreach ($_POST as $key => $value) {
	      if (empty($value) && in_array($key, $required)) {
	        $errors[] = "All fields are required.";
	        break;
	      }
	    }

	    if (empty($errors)) {
    		$user->email = trim($_POST['email']);
	      	$user->password = trim($_POST['password']);
	      	$confirm = trim($_POST['confirm_password']);
	      	$user->usergroup = 400; // 300  - admin, 400 - member

	      	// Get profile property values for profile class
	      	$profile->firstName = sanitize('firstName');
	      	$profile->middleName = sanitize('middleName');
	      	$profile->lastName = sanitize('lastName');
	      	$profile->gender = isset($_POST['gender']) ? $_POST['gender'] : '';
	      	$profile->phone = sanitize('phone');
	      	$profile->address = sanitize('address');
	      	$profile->state_id = sanitize('state_id');
	      	$profile->lga_id = sanitize('lga_id');
	      	$profile->dob = sanitize('dob');

	      	// Further test to check integrity of values
	      	if (!filter_var($user->email, FILTER_VALIDATE_EMAIL)) {
	        	$errors[] = "E-mail is invalid.";
	      	}
	      	if (strlen($user->password) < 6) {
	        	$errors[] = "Password too short.";
	      	}
      		if ($user->password !== $confirm) {
	        	$errors[] = "Passwords do not match";
	      	}
	      	if (strlen($profile->firstName) < 3) {
		        $errors[] = "Please use a valid first name.";
	      	}
	      	if (strlen($profile->lastName) < 3) {
		        $errors[] = "Please use a valid surname.";
	      	}
	      	if (strlen($profile->phone) != 11) {
		        $errors[] = "Phone number must be 11 characters long.";
	      	}
	      	if (!is_numeric($profile->phone)) {
		        $errors[] = "Phone number must be digits.";
	      	}
	      	if (strlen($profile->address) < 10) {
		        $errors[] = "Please, provide a valid address.";
	      	}

	      	// Checking for erros
	      	if (empty($errors)) {
		        // Hash user password with MD5
	          	$user->password = hash('sha1', $user->password);
		        
		        // Commit record to database
        		if ($user->createUser()) {
		          // Assign profileid to user table
		          $profile->user_id = $user->id;
		          $profile->createUserInfo($user->id);

		          // Create record in profile table
		          	if ($profile->createProfile()) {
		            	// Send success message to user, and prompt user to login
			            $session->message("Your profile was created successfully, please login.");
			            redirectTo('index.php');
		          	}
	        	}
	      	}

	    }

	}
 ?>
<?php include_once 'assets/inc/header.php'; ?>

    <?php include_once 'assets/inc/navigation.php'; ?>

	<div class="container" style="margin-bottom: 200px;">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6 mt-4">
				<div class="register-box">
				  <div class="card">
				    <div class="card-body register-card-body">
				      <h4 class="login-box-msg text-center">Register a new membership</h4><hr>
						<?php error($errors); ?>
				      <form action="#" method="post">
				      	<legend>User Account</legend>
				        <div class="form-group">
				          <input type="email" class="form-control" id="email" name="email" placeholder="Email" value="<?php echo stickyForm('email'); ?>">
				        </div>
				        <div class="form-group">
				          <input type="password" class="form-control" name="password" id="password" placeholder="Password">
				        </div>
				        <div class="form-group">
				          <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Retype password">
				        </div>
				        <legend>User Profile</legend>
				        <div class="form-group">
				          <input type="text" class="form-control" name="firstName" id="firstName" placeholder="First name" value="<?php echo stickyForm('firstName'); ?>">
				        </div>
				        <div class="form-group">
				          <input type="text" class="form-control" id="middleName" name="middleName" placeholder="Middle name" value="<?php echo stickyForm('middleName'); ?>">
				        </div>
				        <div class="form-group">
				          <input type="text" class="form-control" id="lastName" name="lastName" placeholder="Last name" value="<?php echo stickyForm('lastName'); ?>">
				        </div>
				        <div class="form-group">
				          <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone Number" value="<?php echo stickyForm('phone'); ?>">
				        </div>
				        <div class="form-group">
				 		  <label for="gender">Gender:</label>&nbsp;
				          <input type="radio" name="gender" value="Male" <?php echo stickyRadio('gender', 'Male'); ?>>Male
				          <input type="radio" name="gender" value="Female" <?php echo stickyRadio('gender', 'Female'); ?>>Female
				        </div>
				        <div class="form-group">
	 						<input type="text" name="dob" id="dob" class="date form-control" placeholder="Select your date of birth" value="<?php echo stickyForm('dob'); ?>">
	 					</div>
	 					<legend>User Address</legend>
	 					<div class="form-group">
	 						<select name="state_id" id="state" class="form-control">
	 							<option value="0">-- Choose State --</option>
	 							<?php foreach ($allStates as $state): ?>
	 								<option value="<?php echo $state['id']; ?>" <?php echo stickySelect('state_id', $state['id']); ?>><?php echo $state['statename']; ?></option>
	 							<?php endforeach ?>
	 						</select>
	 					</div>
	 					<div class="form-group">
	 						<select name="lga_id" id="lga" class="form-control">
	 							<option value="0">-- Choose Local Government --</option>
	 							<?php 
	 								 if (isset($_POST['state_id'])) {
					                    $result = $lga->getLga($_POST['state_id']);
					                  foreach($result as $lga) {
					                      echo "<option value='".$lga['id']."'";
					                      echo stickySelect('lga_id',$lga['id']);
					                      echo ">".$lga['localgovt']."</option>";
					                    }
					                  }
	 							 ?>
	 						</select>
	 					</div>
	 					<div class="form-group">
	 						<textarea name="address" placeholder="Enter your address (140 characters maximum)" id="address" cols="30" rows="3" class="form-control"><?php echo stickyForm('address'); ?></textarea>
	 					</div>
	 					<hr>
				        <div class="row">
				          <div class="col-8">
				            <div class="checkbox icheck">
				              <label>
				                <input type="checkbox"> I agree to the <a href="#">terms</a>
				              </label>
				            </div>
				          </div>
				          <!-- /.col -->
				          <div class="col-4">
				            <button type="submit" name="register_btn" class="btn btn-primary btn-block btn-flat">Register</button>
				          </div>
				          <!-- /.col -->
				        </div>
				      </form>
				      <a href="index.php?note" class="text-center">I already have a membership</a>
				    </div>
				    <!-- /.form-box -->
				  </div><!-- /.card -->
				</div>
				<!-- /.register-box -->
			</div>
			<div class="col-md-3"></div>
		</div>
	</div>
<?php include_once 'assets/inc/footer.php'; ?>
<script>
	// Script for loading local gov't asynchronously
	$(function() {
		$('#state').change(function() {
			var id = $('#state option:selected').val();
			var data = {'id': id};
			$.ajax({
				url: 'assets/asyn/lga.php',
				type: 'POST',
				data: data,
				cache: false,
				success: function(html) {
					$('#lga').html(html);
				},
				error: function() {
					alert('Something went wrong.');
				}
			});
		});
	});
</script>

