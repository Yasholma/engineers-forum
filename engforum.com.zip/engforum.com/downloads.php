<?php require_once 'assets/core/init.php'; ?>
<?php
  $allDocs = !empty($document->getDocuments()) ? $document->getDocuments() : [];
  $i = 1;
 ?>
<?php include_once 'assets/inc/header.php'; ?>

    <?php include_once 'assets/inc/navigation.php'; ?>

    <!-- Page Content -->
    <div class="container-fluid">
      <div class="row">
        <!-- Blog Entries Column -->
        <div class="col-md-10">
          <?php success($session->message()); ?>
          <?php error($errors); ?>
          <div class="row">
            <div class="col-md-12">
              <h1 class="my-4" id="all-post-header">Books &amp; Journals</h1><br>
              <?php if (!loggedIn()): ?>
                <span class="text-danger alert" style="background-color: #fff; padding: 5px;"><a href="index.php?note">Login</a> to download books and journals</span><br>  
              <?php endif ?>
            </div>
          </div>
  
        <!-- Materials (Books and Journals) -->
        <table class="table table-bordered table-inverse table-hover bg-white">
          <thead>
            <tr>
                <th>#</th>
              <th>Title</th>
              <th>Description</th>
              <th>Upload Date</th>
              <th width="2%"></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($allDocs as $doc): ?>  
              <tr>
                <td><?php echo $i++; ?></td>
                <td><?php echo $doc['name']; ?></td>
                <td><?php echo $doc['description']; ?></td>
                <td><?php echo date_to_text($doc['upload_date']); ?></td>
                <td>
                  <?php if (!loggedIn()): ?>
                    <span><a href="index.php?note" class="text-center">Login</a> to download</span>
                  <?php else : ?>
                    <a href="assets/documents/<?php echo $doc['name']; ?>" download>
                      <button class="btn btn-outline-success btn-xs" <?php echo (!loggedIn()) ? ' disabled' : ''; ?>><i class="fa fa-download"></i></button>
                    </a>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach ?>
          </tbody>
        </table>
         


        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-2 mt-4">
          <!-- Search Widget -->
          <?php include_once 'assets/inc/widgets/search.php'; ?>

            <!-- Side Widget -->
            <?php include_once 'assets/inc/widgets/latest_post.php'; ?>

            <!-- Categories Widget -->
            <?php include_once 'assets/inc/widgets/categories.php'; ?>


        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php include_once 'assets/inc/footer.php'; ?>
