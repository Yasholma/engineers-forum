<?php require_once 'assets/core/init.php'; ?>
<?php
    if (isset($_GET['id'])) {
      $post_id = (int)urlencode($_GET['id']);
      $sPost = $post->getPost($post_id);
      $user = $profile->getUserProfile($sPost['user_id']);
      $allComments = !empty($comment->getComments($post_id)) ? $comment->getComments($post_id) : [];

      if (isset($_POST['comment_btn'])) {
        $comment->comment = sanitize('comment');
        $comment->user_id = (int)sanitize('user_id');
        $comment->post_id = (int)sanitize('post_id');

        // Checking to ensure comment box isn't empty
        if ($comment->comment === "") {
          $errors[] = 'Comment box is empty.';
        }

        // Checking the length of comment
        if (strlen($comment->comment) < 10) {
          $errors[] = 'Comment too short.';
        }

        if (empty($errors)) {
          if ($comment->createComment()) {
            $session->message("Comment successfully added.");
            redirectTo("post.php?id=$post_id");
          }
        }
      }
    } else {
      redirectTo('index.php');
    }
 ?>
<?php include_once 'assets/inc/header.php'; ?>

    <?php include_once 'assets/inc/navigation.php'; ?>

    <!-- Page Content -->
    <div class="container">
      <div class="row">
        <!-- Blog Entries Column -->
        <div class="col-md-8 mt-3">
          <a href="<?php echo (isset($_GET['admin'])) ? 'dashboard/post.php' : './'; ?>" class="btn btn-secondary pull-right mt-1"><i class="fa fa-arrow-left"></i> Back to Home</a>
          <h2 class="mb-2" style="color: #fff;"><?php echo $sPost['title']; ?></h2><small>Posted on <?php echo date_to_text($sPost['created_at']); ?> by <?php echo $user['firstName'] .' '. $user['lastName']; ?></small>
          <?php error($errors); success($session->message()); ?>
              <div class="card mt-3">
                <div class="card-body bg-inverse">
                  <p class="lead"><?php echo $sPost['body']; ?></p>
                </div>
              </div>
               <!-- Comments Form -->
              <div class="card my-4">
                <h5 class="card-header">Leave a Comment:</h5>
                <div class="card-body">
                  <form action="" method="POST">
                    <div class="form-group">
                      <textarea class="form-control" rows="3" name="comment"><?php echo stickyForm('comment'); ?></textarea>
                    </div>
                    <input type="hidden" name="post_id" value="<?php echo $sPost['id']; ?>">
                    <input type="hidden" name="user_id" value="<?php echo $_SESSION['us3rid']; ?>">
                    <button type="submit" class="btn btn-primary" <?php echo (!$_SESSION['us3rid']) ? ' disabled' : ''; ?> name="comment_btn">Submit</button>
                    <?php if (!$_SESSION['us3rid']): ?>
                      <span class="text-danger">Login to post comment. <a href="index.php">Login Now</a></span>
                    <?php endif ?>
                  </form>
                </div>
              </div>

              <!-- Single Comment -->
              <?php foreach ($allComments as $cmt): 
                $user_cmt = $profile->getUserProfile($cmt['user_id']);
              ?>       
                <div class="media mb-4" style="color: #000; background-color: #fff; border-radius: 5px;">
                  <!-- <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/50x50" alt=""> -->
                  <div class="media-body p-4">
                    <h5><?php echo $user_cmt['firstName'] .' '. $user_cmt['middleName'] .' '. $user_cmt['lastName']; ?></h5><small>Commented on: <?php echo datetime_to_text($cmt['created_at']); ?></small>
                    <hr>
                    <?php echo $cmt['comment']; ?>
                  </div>
                </div>
              <?php endforeach ?>
        </div>
        <!-- Sidebar Widgets Column -->
        <div class="col-md-4 mt-3">
          <!-- Search Widget -->
          <?php include_once 'assets/inc/widgets/search.php'; ?>

          <!-- Categories Widget -->
          <?php include_once 'assets/inc/widgets/categories.php'; ?>

          <!-- Side Widget -->
          <?php include_once 'assets/inc/widgets/latest_post.php'; ?>

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php include_once 'assets/inc/footer.php'; ?>
