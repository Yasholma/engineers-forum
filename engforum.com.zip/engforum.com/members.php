<?php require_once 'assets/core/init.php'; ?>
<?php
    $i = 1;
    $members = $user->getMembers($_SESSION['us3rid']);
 ?>
<?php include_once 'assets/inc/header.php'; ?>

    <?php include_once 'assets/inc/navigation.php'; ?>

    <!-- Page Content -->
    <div class="container" style="margin-bottom: 370px">
      <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10">
          <?php success($session->message()); ?>
          <?php error($errors); ?>
          <div class="row">
            <div class="col-md-12 text-center">
              <h1 class="my-4" id="all-post-header">All Forum Members</h1><br>
            </div>
          </div>
  
        <!-- Materials (Books and Journals) -->
        <table class="table table-bordered table-inverse table-hover bg-white">
          <thead>
            <tr>
              <th width="2%">#</th>
              <th>Name</th>
              <th>Field</th>
              <th width="7%"></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($members as $m): 
                $id = $m['id'];
                $mInfo = $profile->getInfo($id);
                $memPro = $profile->getUserProfile($id);
            ?>  
              <tr>
                <td><?php echo $i++; ?></td>
                <td><?php echo $memPro['firstName'] .' '.$memPro['middleName'] .' '.$memPro['lastName']; ?></td>
                <td><?php echo !empty($mInfo['field']) ? $mInfo['field'] : '<p class="text-danger">No Data Availble.</p>'; ?></td>
                <td>
                    <a href="p_message.php?rId=<?php echo $m['id']; ?>" class="btn btn-outline-secondary"><i class="fa fa-comment"></i></a>
                </td>
              </tr>
            <?php endforeach ?>
          </tbody>
        </table>

        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-1 mt-4">
        
        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php include_once 'assets/inc/footer.php'; ?>
