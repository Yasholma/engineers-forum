<?php include_once 'assets/core/init.php' ?>
<?php 
	if (!empty($_SESSION['us3rid'])) {
	    $notification = !empty($pchat->getNotify($_SESSION['us3rid'])) ? $pchat->getNotify($_SESSION['us3rid']) : '';
	    $unReadMessages = !empty($pchat->showUnreadMsg($_SESSION['us3rid'])) ? $pchat->showUnreadMsg($_SESSION['us3rid']) : [];
  	}
  ?>
<?php ob_start(); ?>
  <?php if ($notification != ''): ?>
    <?php foreach ($unReadMessages as $msg): ?>
      <?php if ($_SESSION['us3rid'] !== $msg['sId']): 
        $userInfo = $profile->getUserProfile($msg['sId']);
      ?>
        <span class="dropdown-item">
          <small>
            <span><?php echo $userInfo['firstName']; ?></span>
            <small><p><?php echo excerpt($msg['message'], 5); ?></p></small><hr style="margin: 0px">
            <a href="p_message.php?rId=<?php echo $msg['sId']; ?>" onclick="updateIs_read(<?php echo $msg['sId']; ?>,<?php echo $msg['rId']; ?>);" class="btn btn-link btn-xs" style="">view message</a>
          </small>
        </span>
      <?php endif ?>
    <?php endforeach ?>
  <?php else: ?>
      <span class="dropdown-item">
          <small>No new notification.</small>
        </span>
  <?php endif; ?>
<?php echo ob_get_clean(); ?>