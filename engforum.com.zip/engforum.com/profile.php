<?php require_once 'assets/core/init.php'; ?>
<?php 
	if (!loggedIn()) {
		redirectTo('index.php');
	}
	$user_id = $_SESSION['us3rid'];
	$memP = $profile->getUserProfile($user_id);
	$allStates = $state->getStates();
	$memInfo = $profile->getInfo($user_id);

	if (isset($_POST['save_btn'])) {

		$required = ['fName', 'lName', 'phone', 'dob', 'state', 'lga', 'address', 'field', 'about'];
		foreach ($_POST as $key => $value) {
			if (empty($value) && in_array($key, $required)) {
				$errors[] = "All fields are required please.";
				break;
			}
		}

		$profile->firstName = sanitize('fName');
		$profile->middleName = !empty($_POST['mName']) ? sanitize('mName') : false;
		$profile->lastName = sanitize('lName');
		$profile->phone = sanitize('phone');
		$profile->dob = sanitize('dob');
		$profile->state_id = sanitize('state');
		$profile->lga_id = sanitize('lga');
		$profile->address = sanitize('address');
		$profile->field = sanitize('field');
		$profile->about = sanitize('about');

		$file = $_FILES['picture'];

		if (strlen($profile->firstName) < 3) {
	        $errors[] = "Please use a valid first name.";
      	}
      	if (strlen($profile->middleName) < 3) {
	        $errors[] = "Please use a valid middle name.";
      	}
      	if (strlen($profile->lastName) < 3) {
	        $errors[] = "Please use a valid surname.";
      	}
      	if (strlen($profile->phone) != 11) {
	        $errors[] = "Phone number must be 11 characters long.";
      	}
      	if (!is_numeric($profile->phone)) {
	        $errors[] = "Phone number must be digits.";
      	}
      	if (strlen($profile->address) < 10) {
	        $errors[] = "Please, provide a valid address.";
      	}
      	if (strlen($profile->field) < 5) {
      		$errors[] = "Please, provide a valid field.";
      	}
      	if (strlen($profile->about) < 10) {
      		$errors[] = "Please, provide a valid info about yourself.";
      	}
      	if (empty($errors)) {
      		Photograph::$upload_dir = "assets/img/members/";

      		if ($photo->attach_file($file)) {
      			$profile->picture = !empty($photo->filename) ? $photo->filename : $_POST['photo'];
      			if ($photo->save()) {
      				if ($profile->fillProfile($user_id)) {
      					if (file_exists("assets/img/members/" . $_POST['photo'])) {
      						unlink("assets/img/members/" . $_POST['photo']);
      					}
      					$session->message("Profile updated successfully.");
  						redirectTo('profile.php');
      				}
      			} else {
      				$errors[] = join('<br>',$photo->errors);
      			}
      		} else {
      			$errors[] = join('<br>',$photo->errors);
      		} 
      	}
	}
 ?>
 <?php include_once 'assets/inc/header.php'; ?>

    <?php include_once 'assets/inc/navigation.php'; ?>

    <!-- Page Content -->
    <div class="container" style="margin-bottom: 250px;">
      <div class="row">
        <!-- Blog Entries Column -->
        <div class="col-md-12 pt-1">
          <?php success($session->message()); ?>
          <div class="row">
            <div class="col-md-12">
	          	<h1 class="my-4" id="all-post-header"><?php echo (isset($_GET['edit'])) ? 'Edit' : ''; ?> Profile</h1>
            </div>
          </div>
          <div class="row">
          	<?php if (!isset($_GET['edit'])): ?>
          		<div class="col-md-4">
	  				<div class="card">
	  					<img class="card-img-top" src="assets/img/members/<?php echo !empty($memInfo['picture']) ? $memInfo['picture'] : 'no_image.png'; ?>" alt="Card image cap">
	  					<div class="card-block">
							<ul class="list-group">
								<li class="list-group-item"><strong>Field: </strong><em><?php echo $memInfo['field']; ?></em></li>
								<li class="list-group-item"><strong>About Me: </strong><em><p><?php echo $memInfo['about']; ?></p></em></li>
							</ul>
	  					</div>
	  				</div>
	          	</div>

	          	<div class="col-md-8">
	      			<table class="table bg-white table-hover table-bordered mb-5">
	                	<tbody>
		                  <tr>
		                    <th>Name</th>
		                    <td><?php echo $memP['firstName'].' '.$memP['middleName'].' '.$memP['lastName']; ?></td>
		                  </tr>
		                  <tr>
		                    <th>Email Address</th>
		                    <td><?php echo $user->getUserMail($user_id); ?></td>
		                  </tr>
		                  <tr>
		                    <th>Phone Number</th>
		                    <td><?php echo $memP['phone']; ?></td>
		                  </tr>
		                  <tr>
		                    <th>Gender</th>
		                    <td><?php echo $memP['gender']; ?></td>
		                  </tr>
		                  <tr>
		                    <th>Date Of Birth</th>
		                    <td><?php echo date_to_text($memP['dob']); ?></td>
		                  </tr>
		                  <tr>
		                    <th>State</th>
		                    <td><?php echo $state->getState($memP['state_id']); ?></td>
		                  </tr>
		                  <tr>
		                    <th>LGA</th>
		                    <td><?php echo $lga->getLgaById($memP['lga_id']); ?></td>
		                  </tr>
		                  <tr>
		                    <th>Address</th>
		                    <td><?php echo $memP['address']; ?></td>
		                  </tr>
	                </tbody>
	              </table>
	              <div class="row">
	              	<div class="col-md-4">
	              		<a href="./" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Back</a>
	              	</div>
	              	<div class="col-md-8">
	              		<a href="profile.php?edit=<?php echo $user_id; ?>" class="btn btn-primary pull-right"><i class="fa fa-edit"></i> Edit Profile</a>
	              	</div>
	              </div>
	          	</div>
	        <?php else: ?>
				<div class="col-md-4">
					<div>
						<img src="assets/img/members/<?php echo !empty($memInfo['picture']) ? $memInfo['picture'] : 'no_image.png'; ?>" width="200px" height="200px" id="img_prev" name="img_prev" class="img_prev" alt="">
					</div>
				</div>
				<div class="col-md-8">
					<?php error($errors); ?>
					<form action="" method="post" enctype="multipart/form-data">
						<input type="hidden" name="photo" value="<?php echo $memInfo['picture']; ?>">
						<div class="form-group">
							<input type="file" class="form-control" name="picture" id="picture">
						</div>
						<div class="form-inline">
							<input type="text" name="fName" id="fName" value="<?php echo $memP['firstName']; echo stickyForm('firstName'); ?>" placeholder="First Name" class="form-control mr-3">
							<input type="text" name="mName" id="mName" value="<?php echo $memP['middleName']; echo stickyForm('middleName'); ?>" placeholder="Middle Name" class="form-control mr-3">
							<input type="text" name="lName" id="lName" value="<?php echo $memP['lastName']; echo stickyForm('lastName'); ?>" placeholder="Last Name" class="form-control mr-3">
						</div>
						<div class="form-group mt-3">
							<input type="text" name="phone" id="phone" value="<?php echo $memP['phone']; echo stickyForm('phone'); ?>" placeholder="Phone Number" class="form-control">
						</div>
						<div class="form-group mt-3" style="color: #000; background-color: #fff; padding: 6px; border-radius: 5px;">
							<input type="radio" name="gender" id="gender" value="Male" <?php echo ($memP['gender'] == 'Male') ? ' checked' : ''; echo stickyRadio('gender', 'Male'); ?>> Male
							<input type="radio" name="gender" id="gender" value="Female" <?php echo ($memP['gender'] == 'Female') ? ' checked' : ''; echo stickyRadio('gender', 'Female'); ?>> Female
						</div>
						<div class="form-group mt-3">
	 						<input type="text" name="dob" id="dob" class="date form-control" placeholder="Select your date of birth" value="<?php echo stickyForm('dob'); echo $memP['dob']; ?>">
	 					</div>
						<div class="form-group mt-3">
							<select name="state" id="state" class="form-control">
								<option value="<?php echo $memP['state_id']; ?>"><?php echo $state->getState($memP['state_id']); ?></option>
								<?php foreach ($allStates as $st): ?>
									<option value="<?php echo $st['id']; ?>"><?php echo $st['statename']; ?></option>
								<?php endforeach ?>
							</select>
						</div>
						<div class="form-group mt-3">
							<select name="lga" id="lga" class="form-control">
								<option value="<?php echo $memP['lga_id']; ?>"><?php echo $lga->getLgaById($memP['lga_id']); ?></option>
							</select>
						</div>
						<div class="form-group mt-3">
							<input type="text" name="address" id="address" value="<?php echo $memP['address']; echo stickyForm('address'); ?>" placeholder="Address" class="form-control">
						</div>
						<div class="form-group mt-3">
							<input type="text" name="field" id="field" value="<?php echo $memInfo['field']; echo stickyForm('field'); ?>" placeholder="Field (e.g Computer Engineering)" class="form-control">
						</div>
						<div class="form-group mt-3">
							<textarea name="about" id="about" cols="30" rows="3" class="form-control" placeholder="About me"><?php echo stickyForm('about'); echo $memInfo['about']; ?></textarea>
						</div>
						<div class="row">
			              	<div class="col-md-4">
			              		<a href="profile.php" class="btn btn-danger"><i class="fa fa-arrow-left"></i> Cancel</a>
			              	</div>
			              	<div class="col-md-8">
			              		<button name="save_btn" class="btn btn-success pull-right"><i class="fa fa-save"></i> Save Changes</button>
			              	</div>
			              </div>
					</form>
				</div>
          	<?php endif ?>
          	
          </div>
        </div>
      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php include_once 'assets/inc/footer.php'; ?>
<script>
	// Script for loading local gov't asynchronously
	$(function() {
		$('#state').change(function() {
			var id = $('#state option:selected').val();
			var data = {'id': id};
			$.ajax({
				url: 'assets/asyn/lga.php',
				type: 'POST',
				data: data,
				cache: false,
				success: function(html) {
					$('#lga').html(html);
				},
				error: function() {
					alert('Something went wrong.');
				}
			});
		});
	});

	 // Picture preview
 function readURL(input) {
 	if (input.files && input.files[0]) {
 		var reader = new FileReader();

 		reader.onload = function(e) {
 			$('#img_prev').attr('src', e.target.result);
 		}
 		reader.readAsDataURL(input.files[0]);
 	}
 }
 $('#picture').change(function() {
 	readURL(this);
 });
</script>

