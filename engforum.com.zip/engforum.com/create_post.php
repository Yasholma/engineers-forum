<?php require_once 'assets/core/init.php'; ?>
<?php
  if (!loggedIn()) {
    redirectTo('index.php');
  }
  if (isset($_POST['post_btn'])) {
    $required = ['title', 'body'];
    foreach ($_POST as $key => $value) {
      if (empty($value) && in_array($key, $required)) {
        $errors[] = "All fields are required.";
        break;
      }
    }

    if (empty($errors)) {
      $post->user_id = (int)$_SESSION['us3rid'];
      $post->title = sanitize('title');
      $post->body = sanitize('body');
      if (strlen($post->title) < 10) {
        $errors[] = "Please enter a valid post title.";
      }
      if (strlen($post->body) < 15) {
        $errors[] = "Post body is too short.";
      }

      if (empty($errors)) {
        if ($post->createPost()) {
          $session->message("Post added successfully.");
          redirectTo('index.php');
        }
      }
    }
  }
 ?>
<?php include_once 'assets/inc/header.php'; ?>

    <?php include_once 'assets/inc/navigation.php'; ?>

    <!-- Page Content -->
    <div class="container">
      <div class="row">
        <!-- Blog Entries Column -->
        <div class="col-md-8 mt-3">
          <h2 class="display-4 text-warning mb-3">Create New Post</h2>
          <?php error($errors); ?>
              <div class="card">
                <div class="card-block" style="padding: 20px;">
                  <form action="<?php echo basename($_SERVER['PHP_SELF']); ?>" method="post">
                    <div class="form-group">
                      <label for="title">Title:</label>
                      <input type="text" placeholder="Post Title" name="title" id="title" class="form-control" value="<?php echo stickyForm('title'); ?>">
                    </div>
                    <div class="form-group">
                      <label for="body">Body:</label>
                      <textarea name="body" id="body" cols="30" rows="10" placeholder="Post Body" class="form-control"><?php echo stickyForm('body'); ?></textarea>
                    </div>
                    <a href="./" class="btn btn-danger"><i class="fa fa-arrow-left"></i> Cancel</a>
                    <button name="post_btn" class="btn btn-outline-primary pull-right">Post <i class="fa fa-send"></i></button>
                  </form>
                </div>
              </div>
        </div>
        <!-- Sidebar Widgets Column -->
        <div class="col-md-4 mt-3">
          <!-- Search Widget -->
          <?php include_once 'assets/inc/widgets/search.php'; ?>

          <!-- Categories Widget -->
          <?php include_once 'assets/inc/widgets/categories.php'; ?>

          <!-- Side Widget -->
          <?php include_once 'assets/inc/widgets/latest_post.php'; ?>

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php include_once 'assets/inc/footer.php'; ?>
