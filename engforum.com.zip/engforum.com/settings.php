<?php require_once 'assets/core/init.php'; ?>
<?php
  if (!loggedIn()) {
    redirectTo('index.php?note');
  }
  if (isset($_POST['pswBtn'])) {
    $db_password = $user->getUserPassword($_SESSION['us3rid']);
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm = $_POST['confirm'];

    $oldPassHash = hash('sha1', $old_password);

    if ($oldPassHash !== $db_password) {
      $errors[] = "Old password is not correct.";
    }

    if (strlen($new_password) <= 6) {
      $errors[] = "Password length is minimum of 6 characters.";
    }

    if ($new_password !== $confirm) {
      $errors[] = "Password doesn't match.";
    }

    if (empty($errors)) {
      $newPassHash = hash('sha1', $new_password);
      $user->password = $newPassHash;
      if ($user->updatePassword($_SESSION['us3rid'])) {
        $session->message("Your password has been successfully changed.");
        redirectTo('settings.php');
      }
    }
  }
 ?>
<?php include_once 'assets/inc/header.php'; ?>

    <?php include_once 'assets/inc/navigation.php'; ?>

    <!-- Page Content -->
    <div class="container">
      <div class="row">
        <div class="col-md-8 pt-1">
          <?php success($session->message()); ?>
          <?php error($errors); ?>
          <div class="row">
            <div class="col-md-12">
              <h1 class="my-4" id="all-post-header">Settings</h1><br>
            </div>
          </div>
    
        <!-- Settings -->
        <div id="password-change">
          <div class="card">
            <div id="headingOne">
              <h5 class="mb-0">
                <button class="btn btn-primary btn-block" type="button" data-toggle="collapse" data-target="#passwordChange" aria-expanded="true" aria-controls="passwordChange">
                  Change my password
                </button>
              </h5>
            </div>

            <div id="passwordChange" class="collapse" aria-labelledby="headingOne" data-parent="#password-change">
              <div class="card-body">
                <form action="" method="post">
                  <div class="form-group">
                    <input type="password" name="old_password" id="old_password" placeholder="Enter your old password" class="form-control">
                  </div>
                  <div class="form-group">
                    <input type="password" name="new_password" id="new_password" placeholder="Enter your new password" class="form-control">
                  </div>
                  <div class="form-group">
                    <input type="password" name="confirm" id="confirm" placeholder="Confirm Password" class="form-control">
                  </div>
                  <div class="form-group">
                    <button class="btn btn-outline-success btn-block" name="pswBtn">Change Password</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <?php if (!isAdmin()): ?>
          <div class="card mt-3">
            <div class="card-block">
              <button name="blockBtn" class="btn btn-danger btn-block" onclick="blockUser(<?php echo $_SESSION['us3rid']; ?>);">Deactivate my account</button>
            </div>
          </div>
        <?php endif ?>

        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4 mt-4">
          <!-- Search Widget -->
          <?php include_once 'assets/inc/widgets/search.php'; ?>

            <!-- Side Widget -->
            <?php include_once 'assets/inc/widgets/latest_post.php'; ?>

            <!-- Categories Widget -->
            <?php include_once 'assets/inc/widgets/categories.php'; ?>


        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php include_once 'assets/inc/footer.php'; ?>
<script>
  function blockUser(user_id) {
    let data = {userId: user_id};
    if(confirm('Are you sure you want to deactivate your account?\nYou have to contact admin to get reactivated.')) {
      $.ajax({
        url: 'assets/asyn/deactivate.php',
        method: 'POST',
        data: data,
        cache: false,
        success: function(data) {
          if(data == 1) location.reload();
        }
      });
    } else {
      alert("Operation canceled.");
    }
  }
</script>
