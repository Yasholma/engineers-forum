<?php require_once 'assets/core/init.php'; ?>
<?php
  if (isset($_GET['note'])) {
    $note = 1;
  }
  $page = !empty($_GET['page']) ? (int) $_GET['page'] : 1;
  $items_per_page = 3;
  $items_total_count = $post->countAll();

  $paginate = new Paginate($page, $items_per_page, $items_total_count);

  $allPost = !empty($post->count($items_per_page, $paginate->offset())) ? $post->count($items_per_page, $paginate->offset()) : $errors;

  if (isset($_POST['login_btn'])) {
    $user->email = trim($_POST['email']);
    $user->password = trim($_POST['password']);

    // Ensure no required field is empty
    if (!empty($user->email) && !empty($user->password)) {
      // Hash the password
      $user->password = hash('sha1', $user->password);
      if ($user->login($user->email, $user->password)) {
        if ($_SESSION['us3rgr0up'] == 300) {
          if ($user->online($_SESSION['us3rid'])) {
            redirectTo('dashboard');
          }
        }
        if ($user->online($_SESSION['us3rid'])) {
            redirectTo('index.php');
         }
      }
       else {
        $errors[] = "Authentication failed.";
      }
    }
    else {
      $errors[] = "Incorrect credentials.";
    }
  }
 ?>
<?php include_once 'assets/inc/header.php'; ?>

    <?php include_once 'assets/inc/navigation.php'; ?>

    <!-- Page Content -->
    <div class="container">
      <div class="row">
        <!-- Blog Entries Column -->
        <div class="col-md-8 pt-1">
          <?php success($session->message()); ?>
          <?php if (!loggedIn()) : ?>
            <div class="alert alert-danger mt-3">You will have to <a href="register.php">register</a> or login before you can post a message: click the appropriate link to proceed. To start viewing messages, select the forum that you want to visit from the selection below.</div>
          <?php endif ?>
          <?php error($errors); ?>
          <div class="row">
            <div class="col-md-12">
              <h1 class="my-4" id="all-post-header">All Posts</h1>
              <?php if (loggedIn()): ?>
                <a href="create_post.php" class="btn btn-success pull-right mt-4">Create New Post</a>
              <?php endif ?>
            </div>
          </div>

          <!-- Blog Post -->
          <?php include_once 'assets/inc/main_post.php'; ?>

          <!-- Pagination -->
          <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
              <nav>
                <ul class="pagination">
                  <li class="page-item <?=$paginate->has_previous() ? '' : 'disabled'; ?>">
                    <a href="index.php?page=<?=$paginate->has_previous() ? $paginate->previous() : $paginate->current_page;?>" class="page-link" aria-label="Previous">
                      <span aria-hidden="true">&laquo;</span>
                      <span class="sr-only">Previous</span>
                    </a>
                  </li>
                  <?php for ($i = 1; $i <= $paginate->page_total(); $i++) : ?>
                      <?php if ($i == $paginate->current_page) : ?>
                          <li class="active page-item"><a class="page-link" href="index.php?page=<?=$i;?>"><?=$i;?></a></li>
                      <?php else : ?>
                          <li class="page-item"><a class="page-link" href="index.php?page=<?=$i;?>"><?=$i;?></a></li>
                      <?php endif; ?>
                  <?php endfor; ?>
                  <li class="page-item <?=$paginate->has_next() ? '' : 'disabled'; ?>">
                    <a href="index.php?page=<?=$paginate->has_next() ? $paginate->next() : $paginate->current_page;?>" class="page-link" aria-label="Next">
                      <span aria-hidden="true">&raquo;</span>
                      <span class="sr-only">Next</span>
                    </a>
                  </li>
                </ul>
              </nav>
            </div>
            <div class="col-md-3"></div>
          </div>


        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4 mt-4">
          <?php if (!loggedIn()): ?>
            <form action="#" id="login-form" class="border-primary" method="post">
              <div class="form-group">
                <input type="email" name="email" id="email" class="form-control" <?php echo ($note == 1) ? ' autofocus' : ''; ?> placeholder="Email" style="margin-top: -10px;">
              </div>
              <div class="form-group" style="margin-top: -10px;">
                <input type="password" name="password" id="password" class="form-control" placeholder="Password">
              </div>
              <input type="checkbox" name="remember_me" id="remember_me"><label for="remember_me">&nbsp;Remember me?</label>
              <div class="form-group">
                <button class="btn btn-primary" name="login_btn" style="margin-left: 81%;">Login</button>
              </div>
            </form>
          <?php endif ?>
          <!-- Search Widget -->
          <?php include_once 'assets/inc/widgets/search.php'; ?>

            <!-- Side Widget -->
            <?php include_once 'assets/inc/widgets/latest_post.php'; ?>

            <!-- Categories Widget -->
            <?php include_once 'assets/inc/widgets/categories.php'; ?>


        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php include_once 'assets/inc/footer.php'; ?>
