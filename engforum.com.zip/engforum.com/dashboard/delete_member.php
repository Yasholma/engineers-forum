<?php include_once '../assets/core/init.php'; ?>
<?php
if (isset($_GET['delete'])) {
    $id = (int)urlencode($_GET['delete']);
    if ($user->delete($id)) {
        if ($profile->delete($id)) {
            if ($post->delete($id)) {
                if ($comment->delete($id)) {
                    $session->message("Member with related posts and comments has been deleted.");
                    redirectTo('members.php');
                }
            }
        }
    }
} else {
    redirectTo('members.php');
}