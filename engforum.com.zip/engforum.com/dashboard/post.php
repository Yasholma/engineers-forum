<?php include_once '../assets/core/init.php'; ?>
<?php admin(); ?>
<?php
    $i = 1;
    $page = !empty($_GET['page']) ? (int) $_GET['page'] : 1;
    $items_per_page = 5;
    $items_total_count = $post->countAll();

    $paginate = new Paginate($page, $items_per_page, $items_total_count);

    $allPosts = !empty($post->count($items_per_page, $paginate->offset())) ? $post->count($items_per_page, $paginate->offset()) : $errors;
?>
<?php include_once 'includes/_header.php'; ?>
    <div class="wrapper">

        <!-- Navbar -->
        <?php include_once 'includes/_navbar.php'; ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Sidebar -->
            <?php include_once 'includes/_sidebar.php'; ?>
            <!-- /.sidebar -->
        </aside>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="text-white">All Forum Posts</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="./">Home</a></li>
                                <li class="breadcrumb-item active">All Posts</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">

                <!-- Default box -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title mb-2">Posts</h3>
                        <?php success($session->message()); ?>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                                <i class="fa fa-minus"></i></button>
                            <button type="button" class="btn btn-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                                <i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-inverse table-hover">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Date Created</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($allPosts as $pst):
                                $mem_id = $pst['user_id'];
                                $mem_profile = $profile->getUserProfile($mem_id);
                                ?>
                                <tr>
                                    <td><?php echo $pst['id']; ?></td>
                                    <td><?php echo $pst['title']; ?></td>
                                    <td><?php echo $mem_profile['firstName'] .' '. $mem_profile['middleName'] .' '. $mem_profile['lastName'];?></td>
                                    <td><?php echo datetime_to_text($pst['created_at']); ?></td>
                                    <td>
                                        <a href="../post.php?id=<?php echo $pst['id']; ?>&admin" class="btn btn-xs btn-outline-success"><i class="fa fa-eye"></i></a>
                                        <a href="delete_post.php?delete=<?php echo $pst['id']; ?>" class="btn btn-xs btn-danger" onclick="return confirm('Are you sure you want to delete this post?');"><i class="fa fa-remove"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                        <div class="row">
                            <div class="col-md-4">
                                <a href="./" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Back</a>
                            </div>
                            <div class="col-md-1"></div>
                            <div class="col-md-6    ">
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item <?=$paginate->has_previous() ? '' : 'disabled'; ?>">
                                            <a href="post.php?page=<?=$paginate->has_previous() ? $paginate->previous() : $paginate->current_page;?>" class="page-link" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                                <span class="sr-only">Previous</span>
                                            </a>
                                        </li>
                                        <?php for ($i = 1; $i <= $paginate->page_total(); $i++) : ?>
                                            <?php if ($i == $paginate->current_page) : ?>
                                                <li class="active page-item"><a class="page-link" href="post.php?page=<?=$i;?>"><?=$i;?></a></li>
                                            <?php else : ?>
                                                <li class="page-item"><a class="page-link" href="post.php?page=<?=$i;?>"><?=$i;?></a></li>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                        <li class="page-item <?=$paginate->has_next() ? '' : 'disabled'; ?>">
                                            <a href="post.php?page=<?=$paginate->has_next() ? $paginate->next() : $paginate->current_page;?>" class="page-link" aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                                <span class="sr-only">Next</span>
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <!-- /.card-footer-->
                </div>
                <!-- /.card -->

            </section>
            <!-- /.content -->
        </div>
        <!-- Footer -->
        <?php include_once 'includes/_footer.php'; ?>

        <!-- Control Sidebar -->
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->
<?php include_once 'includes/_scripts.php'; ?>