<?php include_once '../assets/core/init.php'; ?>
<?php
    if (isset($_GET['id'])) {
        $id = (int)urlencode($_GET['id']);
        if ($user->block($id)) {
            $session->message("Member has been blocked");
            redirectTo('members.php');
        }
    } elseif (isset($_GET['ban'])) {
        $ban_id = (int)urlencode($_GET['ban']);
        if ($user->unblock($ban_id)) {
            $session->message("Member has been unblocked");
            redirectTo('banned_members.php');
        }
    } else {
        redirectTo('members.php');
    }