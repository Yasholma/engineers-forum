<?php include_once '../assets/core/init.php'; ?>
<?php
if (isset($_GET['delete'])) {
    $post_id = (int)urlencode($_GET['delete']);
    if ($post->delete($post_id)) {
        if ($comment->deleteComment($post_id)) {
            $session->message("Post Deleted Successfully with all comments.");
            redirectTo('post.php');
        }
    }
} else {
    redirectTo('post.php');
}