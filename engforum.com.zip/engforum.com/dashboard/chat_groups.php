<?php include_once '../assets/core/init.php'; ?>
<?php admin(); ?>
<?php 
    $i = 1; 
    $groups = !empty($group->getGroups()) ? $group->getGroups() : [];
 ?>
<?php include_once 'includes/_header.php'; ?>
  <div class="wrapper">

    <!-- Navbar -->
    <?php include_once 'includes/_navbar.php'; ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-warning elevation-4">
      <!-- Sidebar -->
      <?php include_once 'includes/_sidebar.php'; ?>
      <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0 text-white">ENGINEERS FORUM</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active">Chat Rooms</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-3"></div>
              <div class="col-md-6"><?php success($session->message()); ?></div>
              <div class="col-md-3"></div>
            </div>
            <button class="btn btn-outline-warning pull-right mt-1 mr-3" onclick="openModal();">Add Group</button>
            <div class="panel">
              <div class="panel-primary">
                <div class="panel-heading text-uppercase">All Groups</div>
              </div>
              <div class="panel-body bg-white">
                <table class="table table-bordered table-inverse table-hover">
                  <thead>
                    <tr>
                      <th width="2%">#</th>
                      <th>Group Name</th>
                      <th>Date</th>
                      <th width="7%"></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($groups as $g): ?>
                      <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $g['name'] . ' Engineering'; ?></td>
                        <td><?php echo date_to_text($g['created_at']); ?></td>
                        <td>
                          <button class="btn btn-outline-success btn-xs" onclick="openModal();"><i class="fa fa-edit"></i></button>
                          <a href="delete_group.php?del=<?php echo $g['id']; ?>" class="btn btn-outline-danger btn-xs" onclick="return confirm('Are you sure you want to delete this group?');"><span class="fa fa-remove"></span></a>
                        </td>
                      </tr>
                    <?php endforeach ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Add Group Modal -->
        <div class="modal fade" id="addGroupModal">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="alert alert-success" id="info" style="display: none; margin-bottom: -10px">Success</div>
              <div class="modal-header">
                <h4 class="modal-title">Add A Chat Group</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  <span class="sr-only">Close</span>
                </button>
              </div>
              <form action="">
              <div class="modal-body">
                  <input type="text" name="name" id="name" class="form-control" placeholder="Enter chat group name (e.g: Civil, Computer, Mechanical...)">       
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-success" onclick="add_chat_group();"><i class="fa fa-save"></i> Add Group</button>
              </div>
              </form>
            </div><!-- /.modal-content -->
          </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
    <!-- Footer -->
    <?php include_once 'includes/_footer.php'; ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
      <i class="fa fa-user fa-lg"></i>
    </aside>
    <!-- /.control-sidebar -->
  </div>
<!-- ./wrapper -->
<?php include_once 'includes/_scripts.php'; ?>
<script>
  function openModal() {
    $('#addGroupModal').modal('toggle');
  }

  function add_chat_group() {
    let name = $('#name').val();
    let info = $('#info');
    if (name.length < 4) {
      $('#name').addClass('is-invalid')
    } else {
      $('#name').removeClass('is-invalid');
      $('#name').addClass('is-valid');
      let data = {'name':name};
      $.ajax({
        url: 'add_group.php',
        method: 'POST',
        data: data,
        cache: false,
        success: function(data) {
          info.css('display', 'block');
          info.html(data);
          $('#name').val('');
        },
        error: function() {alert('error');}
      });
    }
  }
</script>