<?php include_once '../assets/core/init.php'; ?>
<?php admin(); ?>
<?php
$i = 1;
$allMembers = !empty($user->getBlockedUsers()) ? $user->getBlockedUsers() : [];
?>
<?php include_once 'includes/_header.php'; ?>
    <div class="wrapper">

        <!-- Navbar -->
        <?php include_once 'includes/_navbar.php'; ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Sidebar -->
            <?php include_once 'includes/_sidebar.php'; ?>
            <!-- /.sidebar -->
        </aside>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="text-white">All Forum Members</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="./">Home</a></li>
                                <li class="breadcrumb-item active">All Members</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">

                <!-- Default box -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Members</h3>
                        <?php success($session->message()); ?>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                                <i class="fa fa-minus"></i></button>
                            <button type="button" class="btn btn-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                                <i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-inverse table-hover">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>State</th>
                                <th>LGA</th>
                                <th>Phone Number</th>
                                <th>Gender</th>
                                <th>Date of Birth</th>
                                <th>Status</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($allMembers as $member):
                                $mem_id = $member['id'];
                                $mem_profile = $profile->getUserProfile($mem_id);
                                ?>
                                <tr>
                                    <td><?php echo $i++; ?></td>
                                    <td><?php echo $mem_profile['firstName'] .' '. $mem_profile['middleName'] .' '. $mem_profile['lastName']; ?></td>
                                    <td><?php echo $member['email']; ?></td>
                                    <td><?php echo $state->getState($mem_profile['state_id']); ?></td>
                                    <td><?php echo $lga->getLgaById($mem_profile['lga_id']); ?></td>
                                    <td><?php echo $mem_profile['phone']; ?></td>
                                    <td><?php echo $mem_profile['gender']; ?></td>
                                    <td><?php echo date_to_text($mem_profile['dob']); ?></td>
                                    <td><?php echo ($member['status'] == 0) ? 'Offline' : 'Online'; ?></td>
                                    <td>
                                        <a href="view_member.php?id=<?=$mem_profile['id'];?>" class="btn btn-xs btn-outline-success"><i class="fa fa-eye"></i></a>
                                        <a href="block_member.php?ban=<?=$mem_profile['id'];?>" onclick="return confirm('Are you sure you want to unblock this member?');" class="btn btn-xs btn-outline-warning"><i class="fa fa-eject"></i></a>
                                        <a href="delete_member.php?delete=<?=$mem_profile['id'];?>" onclick="return confirm('Are you sure you want to permanently delete this member?');" class="btn btn-xs btn-danger"><i class="fa fa-remove"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                        <a href="./" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Back</a>
                    </div>
                    <!-- /.card-footer-->
                </div>
                <!-- /.card -->

            </section>
            <!-- /.content -->
        </div>
        <!-- Footer -->
        <?php include_once 'includes/_footer.php'; ?>

        <!-- Control Sidebar -->
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->
<?php include_once 'includes/_scripts.php'; ?>