<?php
require_once '../assets/core/init.php';

if (isset($_GET['del'])) {
	$delete_id = intval($_GET['del']);
	if ($group->deleteGroup($delete_id)) {
		if ($roomC->delete($delete_id)) {
			$session->message("Successfully deleted with group messages.");
			redirectTo('chat_groups.php');
		}	
	}
}
redirectTo('chat_groups.php');