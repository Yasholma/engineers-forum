<?php include_once '../assets/core/init.php'; ?>
<?php admin(); ?>
<?php
    $id = (int)urlencode($_GET['id']);
    $userP = $profile->getUserProfile($id);
    $postCount = $post->countPostByUser($id);
    $mail = $user->getUserMail($id);
    $active = $user->checkActive($id);
    $memInfo = $profile->getInfo($id);
?>
<?php include_once 'includes/_header.php'; ?>
    <div class="wrapper">

        <!-- Navbar -->
        <?php include_once 'includes/_navbar.php'; ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Sidebar -->
            <?php include_once 'includes/_sidebar.php'; ?>
            <!-- /.sidebar -->
        </aside>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="text-white">Dashboard</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="./">Home</a></li>
                                <li class="breadcrumb-item active">Profile</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">

                <!-- Default box -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Members</h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                                <i class="fa fa-minus"></i></button>
                            <button type="button" class="btn btn-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                                <i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-2">
                                <div class="card">
                                    <img src="../assets/img/members/<?php echo $memInfo['picture']; ?>" alt="" class="img-responsive" width="100%" height="100%">
                                    <div class="card-block">
                                        <ul class="list-group">
                                            <li class="list-group-item"><strong>Field:</strong> <?php echo $memInfo['field']; ?></li>
                                            <li class="list-group-item"><strong>Total Post:</strong> <?php echo $postCount; ?></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-10">
                                <table class="table table-striped table-inverse table-hover table-bordered">
                                    <tbody>
                                    <tr>
                                        <th>Name</th>
                                        <td><?php echo $userP['firstName'] .' '. $userP['middleName'] .' '. $userP['lastName']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Email</th>
                                        <td><?php echo $mail; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Gender</th>
                                        <td><?php echo $userP['gender']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Date Of Birth</th>
                                        <td><?php echo date_to_text($userP['dob']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Phone Number</th>
                                        <td><?php echo $userP['phone']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>State</th>
                                        <td><?php echo $state->getState($userP['state_id']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>LGA</th>
                                        <td><?php echo $lga->getLgaById($userP['lga_id']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Address</th>
                                        <td><?php echo $userP['address']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Active</th>
                                        <td><?php echo ($active == 1) ? 'Active' : 'Blocked'; ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                                <h4 class="mt-2 pl-1">Bio: ________________________________________________________________________________</h4>  
                                <p class="p-1"><?php echo $memInfo['about']; ?></p>
                            </div>
                        </div>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                        <a href="members.php" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Back</a>
                    </div>
                    <!-- /.card-footer-->
                </div>
                <!-- /.card -->

            </section>
            <!-- /.content -->
        </div>
        <!-- Footer -->
        <?php include_once 'includes/_footer.php'; ?>

        <!-- Control Sidebar -->
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->
<?php include_once 'includes/_scripts.php'; ?>

