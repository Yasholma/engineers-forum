<?php include_once '../assets/core/init.php'; ?>
<?php admin(); ?>
<?php
    if (isset($_POST['upload_doc'])) {
        // Handle upload document
        $file = $_FILES['document'];
        Document::$upload_dir = "../assets/documents/";
        if ($file['name'] == '') {
            $errors[] = 'Please select a valid file.';
        }
        $document->description = sanitize('description');
        if ($document->description == '') {
            $errors[] = "Please, provide a description of book or journal.";
        }

        if (empty($errors)) {
            if ($document->attach_file($file)) {
                $document->name = $document->filename;
                // Saving to folder
                if ($document->save()) {
                    // saving name to database
                    if ($document->save_to_db()) {
                        $session->message("Document uploaded successfully.");
                        redirectTo('add_document.php');
                    }
                } else {
                    // join all the errors
                    $errors[] = join('<br>',$document->errors);
                }
            } else {
                // join all the errors
                $errors[] = join('<br>',$document->errors);
            }
        }
    }
?>
<?php include_once 'includes/_header.php'; ?>
    <div class="wrapper">

        <!-- Navbar -->
        <?php include_once 'includes/_navbar.php'; ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Sidebar -->
            <?php include_once 'includes/_sidebar.php'; ?>
            <!-- /.sidebar -->
        </aside>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="text-white">Documents</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="./">Home</a></li>
                                <li class="breadcrumb-item active">Journals &amp; Books</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">

                <!-- Default box -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title mb-2">All Journals &amp; Books</h3>
                        <?php error($errors); success($session->message()); ?>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                                <i class="fa fa-minus"></i></button>
                            <button type="button" class="btn btn-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                                <i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="add_document.php" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="document">Upload Journal/Book</label>
                                <input type="file" class="form-control" name="document" id="document">
                            </div>
                            <div class="form-group">
                                <textarea name="description" id="description" class="form-control" placeholder="Description" cols="30" rows="5"><?php echo stickyForm('decription'); ?></textarea>
                            </div>
                            <div class="form-group">
                                <input type="submit" value="Upload" name="upload_doc" class="btn btn-outline-warning">
                            </div>
                        </form>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                        <a href="./" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Back</a>
                    </div>
                    <!-- /.card-footer-->
                </div>
                <!-- /.card -->

            </section>
            <!-- /.content -->
        </div>
        <!-- Footer -->
        <?php include_once 'includes/_footer.php'; ?>

        <!-- Control Sidebar -->
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->
<?php include_once 'includes/_scripts.php'; ?>