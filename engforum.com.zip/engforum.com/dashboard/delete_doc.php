<?php include_once '../assets/core/init.php'; ?>
<?php
    if (isset($_GET['del'])) {
        $id = $_GET['del'];
        $doc = $document->getDocument($id);
        $filename = $doc['name'];
        if ($document->delete($id)) {
            if (file_exists("../assets/documents/".$filename)) {
                unlink("../assets/documents/".$filename);
            }
            $session->message("Document has been deleted successfully.");
            redirectTo('documents.php');
        }

    }
    redirectTo('documents.php');