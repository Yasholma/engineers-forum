 <footer class="main-footer text-center">
  <strong>Copyright &copy; <?php echo date('Y'); ?> Smartphones HUB.</strong>
  All rights reserved.
</footer>