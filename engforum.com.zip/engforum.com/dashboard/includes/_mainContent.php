<?php 
	$totalUsers = $user->countAll();
	$totalPosts = $post->countAll();
	$blockMembers = $user->countBlockedUsers();
	$countDocs = $document->countAll();
	$activeMembers = $user->countActive();
 ?>

<!-- Main content -->
<section class="content">
	<div class="container-fluid">
	<!-- Small boxes (Stat box) -->
	<div class="row">
	  <div class="col-lg-6 col-6">
	    <!-- small box -->
	    <div class="small-box bg-info">
	      <div class="inner">
	        <h3><?php echo $totalUsers; ?></h3>

	        <h2 class="display-4">All Members</h2>
	      </div>
	      <div class="icon">
	        <i class="fa fa-users"></i>
	      </div>
	      <a href="members.php" class="small-box-footer">View All Members <i class="fa fa-arrow-circle-right"></i></a>
	    </div>
	  </div>
	  <!-- ./col -->
	  <div class="col-lg-6 col-6">
	    <!-- small box -->
	    <div class="small-box bg-success">
	      <div class="inner">
	        <h3><?php echo $totalPosts; ?></h3>

	        <h2 class="display-4">Posts</2>
	      </div>
	      <div class="icon">
	        <i class="fa fa-comment-o"></i>
	      </div>
	      <a href="post.php" class="small-box-footer">View All Posts <i class="fa fa-arrow-circle-right"></i></a>
	    </div>
	  </div>
	  <!-- ./col -->
	  <div class="col-lg-6 col-6">
	    <!-- small box -->
	    <div class="small-box bg-warning">
	      <div class="inner">
	        <h3><?php echo $activeMembers; ?></h3>

	        <h2 class="display-4">Active Members</h2>
	      </div>
	      <div class="icon">
	        <i class="fa fa-plus"></i>
	      </div>
	      <a href="active_members.php" class="small-box-footer">View Active Members <i class="fa fa-arrow-circle-right"></i></a>
	    </div>
	  </div>
	  <!-- ./col -->
	  <div class="col-lg-6 col-6">
	    <!-- small box -->
	    <div class="small-box bg-danger">
	      <div class="inner">
	        <h3><?php echo $blockMembers; ?></h3>

	        <h2 class="display-4">Blocked Members</h2>
	      </div>
	      <div class="icon">
	        <i class="fa fa-ban"></i>
	      </div>
	      <a href="banned_members.php" class="small-box-footer">View Banned Members <i class="fa fa-arrow-circle-right"></i></a>
	    </div>
	  </div>
   		<!-- ./col -->
	  <div class="col-lg-6 col-6">
	    <!-- small box -->
	    <div class="small-box bg-info">
	      <div class="inner">
	        <h3><?php echo $countDocs; ?></h3>

	        <h2 class="display-4">Documents</h2>
	      </div>
	      <div class="icon">
	        <i class="fa fa-book"></i>
	      </div>
	      <a href="documents.php" class="small-box-footer">View All Documents <i class="fa fa-arrow-circle-right"></i></a>
	    </div>
	  </div>
	  <!-- ./col -->
	</div>
	<!-- /.row -->
	<!-- Main row -->
	<div class="row">
	  <!-- Left col -->
	  <section class="col-lg-7 connectedSortable">
	    
	  </section>
	  <!-- /.Left col -->
	</div>
	<!-- /.row (main row) -->
	</div><!-- /.container-fluid -->
</section>