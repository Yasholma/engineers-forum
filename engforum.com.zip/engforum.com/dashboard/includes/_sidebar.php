<!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="../assets/img/site_logo.png" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="index.php" class="d-block">Forum Administrator</a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="index.php" class="nav-link <?php echo ($page == 'index.php') ? ' active' : ''; ?>">
              <i class="nav-icon fa fa-dashboard"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview menu-open">
            <a href="../profile.php" class="nav-link <?php echo ($page == 'profile.php') ? ' active' : ''; ?>">
              <i class="nav-icon fa fa-product-hunt"></i>
              <p>
                Profile
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link <?php echo ($page == 'members.php' || $page == 'banned_members.php') ? 'active' : ''; ?>">
              <i class="nav-icon fa fa-users"></i>
              <p>
                Manage Members
                <i class="fa fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="members.php" class="nav-link">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>All Members</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="banned_members.php" class="nav-link">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>Blocked Members</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link <?php echo ($page === 'post.php') ? 'active' : ''; ?>">
              <i class="nav-icon fa fa-plus-square-o"></i>
              <p>
                Manage Posts
                <i class="fa fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="post.php" class="nav-link">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>All Posts</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link <?php echo ($page == 'documents.php' || $page == 'add_document.php') ? 'active' : ''; ?>">
              <i class="nav-icon fa fa-book"></i>
              <p>
                Journals &amp; Books
                <i class="fa fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="documents.php" class="nav-link">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>All Documents</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="add_document.php" class="nav-link">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>Add Journals/Books</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="chat_groups.php" class="nav-link <?php echo ($page == 'chat_groups.php' || $page == 'add_group.php') ? 'active' : ''; ?>">
              <i class="nav-icon fa fa-comments"></i>
              <p>
                Chat Groups
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="../logout.php" class="nav-link">
              <i class="nav-icon fa fa-sign-out"></i>
              <p>
                Logout
                <span class="right badge badge-danger"><i class="fa fa-power-off"></i></span>
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
  