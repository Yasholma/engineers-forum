<?php include_once '../assets/core/init.php'; ?>
<?php 
	$info = '';
	if (isset($_POST['name'])) {
		$name = trim(sanitize('name'));
		$group->name = ucfirst($name);
		if (strlen($name) > 3) {
			if ($group->addGroup()) {
				$info = "$group->name Engineering has been added Successfully.";
			}
		}
	}
	echo $info;
 ?>