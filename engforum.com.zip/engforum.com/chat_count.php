<?php include_once 'assets/core/init.php' ?>
<?php 
	if (!empty($_SESSION['us3rid'])) {
	    $notification = !empty($pchat->getNotify($_SESSION['us3rid'])) ? $pchat->getNotify($_SESSION['us3rid']) : '';
  	}
  	ob_start();
  ?>
	<span class="badge badge-danger"><?php echo $notification; ?></span>
  <?php echo ob_get_clean(); ?>