<?php include_once '../../assets/core/init.php' ?>
<?php
if (isset($_POST['msg']) && isset($_POST['group_id'])) {
    $user_id = (int)$_SESSION['us3rid'];
    $group_id = (int)$_POST['group_id'];
    $msg = sanitize('msg');

    $result = $roomC->addMessage($user_id, $msg, $group_id);
}