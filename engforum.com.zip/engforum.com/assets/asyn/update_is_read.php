<?php include_once '../../assets/core/init.php' ?>
<?php 
	$sId = (int)sanitize('sId');
	$rId = (int)sanitize('rId');
	if ($pchat->seen($sId, $rId)) {
		
	}
	echo $rId;
 ?>