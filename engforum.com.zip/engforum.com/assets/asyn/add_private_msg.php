<?php include_once '../../assets/core/init.php' ?>
<?php 
	if (isset($_POST['msg'])) {
		$sId = (int)$_POST['sId'];
		$rId = (int)$_POST['rId'];
		$msg = sanitize('msg');

		$pchat->sId = $sId;
		$pchat->rId = $rId;
		$pchat->message = $msg;
		$result = $pchat->addMessage();
	}