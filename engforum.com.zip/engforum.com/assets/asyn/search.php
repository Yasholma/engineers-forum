<?php include_once '../../assets/core/init.php' ?>
<?php
if (isset($_POST['search'])) {
    $name = $_POST['search'];
    $searchRes = !empty($post->search($name)) ? $post->search($name) : [];
}
ob_start();
?>
    <ul class="list" style="padding: 3px;">
        <?php foreach ($searchRes as $res): ?>
            <li><a href="post.php?id=<?php echo $res['id']; ?>"><?php echo $res['title']; ?></a></li><br>
        <?php endforeach ?>
    </ul>
<?php echo ob_get_clean(); ?>