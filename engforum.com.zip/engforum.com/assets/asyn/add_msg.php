<?php include_once '../../assets/core/init.php' ?>
<?php 
	if (isset($_POST['msg'])) {
		$user_id = (int)$_SESSION['us3rid'];
		$msg = sanitize('msg');

		$result = $chat->addMessage($user_id, $msg);
	}