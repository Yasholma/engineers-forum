<?php include_once '../../assets/core/init.php' ?>
<?php 
	$id = (int)sanitize('id');
	if ($id > 0) {
		$allLga = $lga->getLga($id);
	}
	ob_start();
 ?>
	<?php foreach ($allLga as $lga): ?>
		<option value="<?php echo $lga['id']; ?>"><?php echo $lga['localgovt']; ?></option>
	<?php endforeach ?>

 <?php echo ob_get_clean(); ?>