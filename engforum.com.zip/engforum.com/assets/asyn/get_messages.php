<?php include_once '../../assets/core/init.php' ?>
<?php
    $chatMessages = $chat->getMessages();
    ob_start();
?>
	<?php if (!empty($chatMessages)): ?>
		<?php foreach ($chatMessages as $msg): ?>
	        <?php if ($msg['id'] == $_SESSION['us3rid']): ?>
	            <div class="alert alert-success" style="display: block;">
	                <?php echo $msg['message'] . '<br>'; ?>
	                <small><?php echo datetime_to_text($msg['send_date']) . '<br>'; ?></small>
	            </div><br>
	        <?php else: ?>
	            <div class="alert alert-info text-right pull-right" style="display: block;"> 
	                <strong><?php echo $profile->getUserProfile($msg['id'])['firstName']; ?></strong><hr>
	                <?php echo $msg['message'] . '<br>';  ?>
	                <small><?php echo datetime_to_text($msg['send_date']) . '<br>'; ?></small>
	            </div><br><br><br><br><br><br><br>
	        <?php endif; ?>
	    <?php endforeach ?>
	<?php else : ?>
		<?php echo "<span style='margin-left: 25px;'>No Chat messages available</span>"; ?>
	<?php endif; ?>
<?php 
    echo ob_get_clean();
?>
