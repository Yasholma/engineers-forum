<?php include_once '../../assets/core/init.php' ?>
<?php
$sId = (int)$_GET['sId'];
$rId = (int)$_GET['rId'];
$pMessages = $pchat->getMessages($sId, $rId);
ob_start();
?>
<?php if (!empty($pMessages)): ?>
    <?php foreach ($pMessages as $msg): ?>
        <?php if ($msg['sId'] == $sId): ?>
            <div class="alert alert-success" style="display: block;">
                <?php echo $msg['message'] . '<br>'; ?>
                <small><?php echo datetime_to_text($msg['timestamp']) . '<br>'; ?></small>
            </div><br>
        <?php else: ?>
            <div class="alert alert-info text-right pull-right" style="display: block;"> 
                <strong><?php echo $profile->getUserProfile($msg['rId'])['firstName']; ?></strong><hr>
                <?php echo $msg['message'] . '<br>';  ?>
                <small><?php echo datetime_to_text($msg['timestamp']) . '<br>'; ?></small>
            </div><br><br><br><br><br><br><br>
        <?php endif; ?>
    <?php endforeach ?>
<?php else : ?>
    <?php echo "<span style='margin-left: 25px;'>No Chat messages available</span>"; ?>
<?php endif; ?>
<?php
echo ob_get_clean();
?>
