<?php include_once '../../assets/core/init.php' ?>
<?php 
	$userId = (int)$_POST['userId'];
	if ($user->block($userId)) {
		if ($user->offline($userId)) {
			if ($user->logout()) {
				echo 1;
			}
		}
	}
 ?>