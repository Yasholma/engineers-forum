<div class="card my-4">
  <h5 class="card-header">Categories</h5>
  <div class="card-body">
    <div class="row">
      <div class="col-lg-8">
        <ul class="list-unstyled mb-0">
          <li>
            <a href="#">Journals</a>
          </li>
          <li>
            <a href="#">Posts</a>
          </li>
          <li>
            <a href="#">Most Commented Post</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>