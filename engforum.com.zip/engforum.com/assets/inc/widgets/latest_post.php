<?php include_once 'assets/core/init.php'; ?>
<?php
    $post = new Post();
    $topPosts = $post->getTopPosts();
?>
<div class="card my-4">
	<h5 class="card-header">Top Posts</h5>
	<div class="card-body">
	  		<ul class="list-group">
                <?php foreach ($topPosts as $tPost) : ?>
	  			    <li class="list-group-item"><a href="post.php?id=<?php echo $tPost['id']; ?>"><?php echo $tPost['title']; ?></a></li>
                <?php endforeach; ?>
	  		</ul>
	</div>
</div>