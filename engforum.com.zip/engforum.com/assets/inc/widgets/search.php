<div class="card my-4">
  <h5 class="card-header">Search</h5>
  <div class="card-body">
    <div class="input-group">
        <form action="" class="col-md-12 mb-4">
            <input type="text" class="form-control" placeholder="Search Posts" id="search">
        </form>
        <div id="display" style="padding: 0px; margin-top: 0px; margin-left: 11px;">

        </div>
    </div>
  </div>
</div>