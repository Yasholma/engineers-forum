<?php $allPost = !empty($post->count($items_per_page, $paginate->offset())) ? $post->count($items_per_page, $paginate->offset()) : $errors; ?>
<?php foreach ($allPost as $post): ?>
	<div class="card mb-2">
	  <div class="card-body">
	    <h2 class="card-title"><?php echo $post['title']; ?></h2>
	    <p class="card-text"><?php echo excerpt($post['body'], 15); ?></p>
	    <a href="post.php?id=<?php echo $post['id']; ?>" class="btn btn-outline-primary pull-right">Read More &rarr;</a>
	  </div>
	  <div class="card-footer text-muted">
	    Posted on <?php echo datetime_to_text($post['created_at']); ?> by
	    <a href="user_post.php?user_id=<?php echo $post['user_id']; ?>"><?php echo $profile->getUserProfile($post['user_id'])['firstName']; ?></a>
	  </div>
	</div>
<?php endforeach ?>


