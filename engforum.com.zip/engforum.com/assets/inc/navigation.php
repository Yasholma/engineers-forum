<?php 
  $groups = $group->getGroups();
  if (!empty($_SESSION['us3rid'])) {
    $notification = !empty($pchat->getNotify($_SESSION['us3rid'])) ? $pchat->getNotify($_SESSION['us3rid']) : '';
    $unReadMessages = !empty($pchat->showUnreadMsg($_SESSION['us3rid'])) ? $pchat->showUnreadMsg($_SESSION['us3rid']) : [];
  }
  
 ?>
<!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-info fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">
           <img src="assets/img/site_logo.png" id="logo" class="img-fluid ml-5" alt="Engineer's Forum" width="38px;"> <h5 class="mt-3" style="display: inline;">THE NIGERIAN SOCIETY OF ENGINEERS ONLINE INTERACTIVE FORUM</h5>
        </a>
        <div class="dropdown mr-2 chatNotification hidden-sm hidden-md hidden-lg ml-5">
          <button class="btn btn-outline-secondary" type="button" id="dropdownMenu1" data-placement="bottom" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-bell"></i><sup class="chatInfo"></sup>
          </button>
          <div class="dropdown-menu chatNotify">
                  
          </div>
        </div>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="index.php"><i class="fa fa-home"></i>
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="downloads.php">Downloads</a>
            </li>
            <li class="nav-item mr-2">
              <a class="nav-link" href="about.php">About Us</a>
            </li>
            <?php if (loggedIn()): ?>
              <li class="nav-item mr-2">
                <a class="nav-link" href="members.php">Members</a>
              </li>
              <div class="dropdown mr-2">
                <button class="btn btn-outline-secondary" type="button" id="dropdownMenu1" data-placement="bottom" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="fa fa-bell"></i><sup class="chatInfo"></sup>
                </button>
                <div class="dropdown-menu chatNotify">
                  
                </div>
              </div>
            <div class="dropdown mr-2">
                <button type="button" class="btn btn-outline-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #fff;">
                  Chat House
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="chat_groups.php?id=<?=$_SESSION['us3rid'];?>">General Room</a>
                    <?php foreach ($groups as $g): ?>
                      <a class="dropdown-item" href="room.php?name=<?php echo strtolower($g['name']); ?>&room=<?php echo $g['id']; ?>"><?php echo $g['name']; ?> Engineering</a>
                    <?php endforeach ?>
                </div>
            </div>
            <?php endif ?>
            <?php if (!loggedIn()): ?>
              <li class="nav-item <?php ($page == 'register.php') ? 'active' : ''; ?>">
                <a class="nav-link" href="register.php">Register</a>
              </li>
            <?php else: ?>
               <div class="dropdown">
                  <button class="btn btn-outline-secondary dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #fff;">
                    <i class="fa fa-user"></i> <?php echo $profile->getUserProfile($_SESSION['us3rid'])['firstName']; ?>
                  </button>
                  <div class="dropdown-menu" aria-labelledby="dropdownMenu1">
                    <?php if (isAdmin()): ?>
                      <a class="dropdown-item" href="dashboard"><i class="fa fa-dashboard"></i> Dashboard</a>
                    <?php else: ?>
                      <a class="dropdown-item" href="profile.php"><i class="fa fa-product-hunt"></i> Profile</a>
                    <?php endif ?>
                    <a class="dropdown-item" href="settings.php"><i class="fa fa-cog"></i> Settings</a>
                    <div role="separator" class="dropdown-divider"></div>
                    <a class="dropdown-item" href="logout.php">Logout <i class="fa fa-sign-out"></i></a>
                  </div>
                </div>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </nav>

