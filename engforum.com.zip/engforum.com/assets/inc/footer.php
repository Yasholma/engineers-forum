    <!-- Footer -->
    <footer class="py-5 bg-info" id="footer">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Engineers Forum 2018</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <!-- <script src="assets/js/jquery.min.js"></script> -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/bootstrap-datepicker.min.js"></script>
    <script src="assets/js/bootstrap-datepicker.en-IE.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="assets/js/holder.min.js"></script>
    <script>
      $('.date').datepicker();

      $(function () {
        $('[data-toggle="popover"]').popover()
      });

      function updateIs_read(sId, rId) {
        let data = {sId: sId, rId, rId};
        $.ajax({
          url: 'assets/asyn/update_is_read.php',
          method: 'POST',
          data: data,
          cache: false,
          success: function(data) {
            
          }
          
        });
      }

      function load_notifcation() {
        let notifcation = $('.chatNotify');
        notifcation.load('load_notificaton.php');
      }

      function load_chat_count() {
        let chatInfo = $('.chatInfo');
        chatInfo.load('chat_count.php');
      }

      setInterval(load_notifcation, 1000);
      setInterval(load_chat_count, 1000);

      $(document).ready(function() {
          $('#search').keyup(function() {
              let name = $('#search').val();
              let data = {'search':name};
              if (name === '') {
                  $('#display').html("");
              } else {
                  $.ajax({
                      url: 'assets/asyn/search.php',
                      type: 'POST',
                      data: data,
                      cache: false,
                      success: function(data) {
                          $('#display').html(data).show();
                      },
                      error: function() {
                          alert("Error Occurred.");
                      }
                  });
              }
          });
      });
    </script>

  </body>

</html>