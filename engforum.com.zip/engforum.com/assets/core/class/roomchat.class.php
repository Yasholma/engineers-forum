<?php
	class RoomChat {
		private $connection;
		public $user_id, $message, $send_date, $group_id;

		public function __construct()
        {
            $this->connection = new Connection();
            $this->connection = $this->connection->connect();
        }

        public function getMessages($group_id) {
		    $statement = $this->connection->prepare("SELECT r.message, r.send_date, u.id, u.email FROM user u JOIN room_chat r ON r.user_id = u.id WHERE group_id = $group_id ORDER BY send_date");
		    $statement->execute();
		    $result = $statement->fetchAll(PDO::FETCH_ASSOC);

		    return $result ? $result : false;
        }

        public function addMessage($user_id, $message, $group_id) {
		    $statement = $this->connection->prepare("INSERT INTO room_chat (user_id, message, group_id) VALUES (?, ?, ?)");
		    $statement->bindValue(1, $user_id);
		    $statement->bindValue(2, $message);
		    $statement->bindValue(3, $group_id);
		    $result = $statement->execute();


		    return $result ? true : false;
        }

        public function delete($group_id) {
        	$statement = $this->connection->prepare("DELETE FROM room_chat WHERE group_id = $group_id");
        	$result = $statement->execute();

        	return $result ? true : false;
        }

    }