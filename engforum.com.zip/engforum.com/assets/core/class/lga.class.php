<?php
class Lga {
	private $connection;
	public $id, $stateid, $localgovt, $lgacode;

	public function __construct() {
		$this->connection = new Connection();
		$this->connection = $this->connection->connect();
	}

	// Create record in database table
	public function createLga() {
		$statement = $this->connection->prepare("INSERT INTO tbl_lga (stateid, localgovt, localcode) VALUES (?, ?, ?)");
		// Bind all values to the placeholders
		$statement->bindParam(1, $this->stateid);
		$statement->bindParam(2, $this->localgovt);
		$statement->bindParam(3, $this->localcode);

		// Execute the query
		$result = $statement->execute();

		return $result ? true : false;
	}

	// Read row(s) from the database table
	public function getLgas() {
		$statement = $this->connection->prepare("SELECT * FROM tbl_lga");
		$statement->execute();
		$results = $statement->fetchAll(PDO::FETCH_ASSOC);

		return $results ? $results : false;
	}

	public function getLga($stateid) {
		$statement = $this->connection->prepare("SELECT * FROM tbl_lga WHERE stateid = :stateid");
		$statement->execute(array("stateid"=>$stateid));
		$results = $statement->fetchAll(PDO::FETCH_ASSOC);

		return $results ? $results : false;
	}

	public function getLgaById($id) {
		$statement = $this->connection->prepare("SELECT * FROM tbl_lga WHERE id = :id");
		$statement->execute(array("id"=>$id));
		$result = $statement->fetch();

		// $this->id = $result['id'];
		// $this->localgovt = $result['localgovt'];

		return $result ? $result['localgovt'] : false;
	}

	public function countAll() {
		$statement = $this->connection->prepare("SELECT COUNT(*) AS count FROM tbl_lga");
		$statement->execute();
		$result = $statement->fetch();

		return $result ? $result['count'] : false;
	}

	// Update row in table

	// Delete record from table
}
