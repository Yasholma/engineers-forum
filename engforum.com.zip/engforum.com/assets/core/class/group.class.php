<?php
	class Group {
		private $connection;
		public $id, $name;

		public function __construct() {
			$this->connection = new Connection();
			$this->connection = $this->connection->connect();
		}

		public function addGroup() {
			$statement = $this->connection->prepare("INSERT INTO chat_group (name) VALUES (?)");
			$statement->bindValue(1, $this->name);
			$result = $statement->execute();

			return $result ? true : false;
		}

		public function getGroups() {
			$statement = $this->connection->prepare("SELECT * FROM chat_group");
			$statement->execute();
			$result = $statement->fetchAll(PDO::FETCH_ASSOC);

			return $result ? $result : false;
		}

		public function getGroup($id) {
			$statement = $this->connection->prepare("SELECT * FROM chat_group WHERE id = ?");
			$statement->bindValue(1, $id);
			$statement->execute();
			$result = $statement->fetch();

			return $result ? $result : false;
		}

		public function editGroup($id) {
			$statement = $this->connection->prepare("UPDATE chat_group SET name = ? WHERE id = ?");
			$statement->bindValue(1, $this->name);
			$statement->bindValue(2, $id);
			$result = $statement->execute();

			return $result ? true : false;
		}

		public function deleteGroup($id) {
			$statement = $this->connection->prepare("DELETE FROM chat_group WHERE id = $id");
			$result = $statement->execute();

			return $result ? true : false;
		}
	}