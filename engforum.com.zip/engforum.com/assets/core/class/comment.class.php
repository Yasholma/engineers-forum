<?php 
	class Comment {
		private $connection;
		public $id, $comment, $user_id, $post_id;

		public function __construct() {
			$this->connection = new Connection();
			$this->connection = $this->connection->connect();
		}

		public function createComment() {
			$statement = $this->connection->prepare("INSERT INTO comment (comment, user_id, post_id) VALUES(?, ?, ?)");
			$statement->bindValue(1, $this->comment);
			$statement->bindValue(2, $this->user_id);
			$statement->bindValue(3, $this->post_id);

			$result = $statement->execute();
			return $result ? true : false;
		}

		public function getComments($post_id) {
			$statement = $this->connection->prepare("SELECT * FROM comment WHERE post_id = ?");
			$statement->bindValue(1, $post_id);
			$statement->execute();

			$result = $statement->fetchAll(PDO::FETCH_ASSOC);	
			return $result ? $result : false;
		}

		public function delete($user_id) {
			$statement = $this->connection->prepare("DELETE FROM comment WHERE user_id = $user_id");
			$result = $statement->execute();

			return $result ? true : false;
		}

		public function deleteComment($post_id) {
            $statement = $this->connection->prepare("DELETE FROM comment WHERE post_id = $post_id");
            $result = $statement->execute();

            return $result ? true : false;
        }
	}