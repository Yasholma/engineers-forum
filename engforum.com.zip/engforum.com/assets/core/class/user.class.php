<?php 
	class User {
		private $connection;
		public $id, $email, $password, $usergroup, $status, $is_active;

		public function __construct() {
			$this->connection = new Connection();
			$this->connection = $this->connection->connect();
		}

		// Create record in database table
		public function createUser() {
			$statement = $this->connection->prepare("INSERT INTO user (email, password, usergroup) VALUES (?, ?, ?)");
			// Bind all values to the placeholders
			$statement->bindParam(1, $this->email);
			$statement->bindParam(2, $this->password);
			$statement->bindParam(3, $this->usergroup);
			// Execute the query
			$result = $statement->execute();

			$this->id = $this->connection->lastInsertId();
			
			return $result ? true : false;
		}

        public function block($id) {
            $statement = $this->connection->prepare("UPDATE user SET is_active = 0 WHERE id = ?");
            $statement->bindValue(1, $id);
            $result = $statement->execute();

            return $result ? true : false;
        }

        public function unblock($id) {
            $statement = $this->connection->prepare("UPDATE user SET is_active = 1 WHERE id = ?");
            $statement->bindValue(1, $id);
            $result = $statement->execute();

            return $result ? true : false;
        }

		public function logout() {
			if (isset($_SESSION['us3rid'])){
				unset($_SESSION['us3rid']);
				session_destroy();

				return true;
			}
			return false;
		}

		// Get user email
		public function getUserMail($id) {
			$statement = $this->connection->prepare("SELECT email FROM user WHERE id = ?");
			$statement->bindValue(1, $id);
			$statement->execute();

			$result = $statement->fetch();

			return $result ? $result['email'] : false;
		}

		public function getUserPassword($id) {
			$statement = $this->connection->prepare("SELECT password FROM user WHERE id = ?");
			$statement->bindValue(1, $id);
			$statement->execute();

			$result = $statement->fetch();

			return $result ? $result['password'] : false;
		}

		public function checkActive($id) {
			$statement = $this->connection->prepare("SELECT is_active FROM user WHERE id = ?");
			$statement->bindValue(1, $id);
			$statement->execute();

			$result = $statement->fetch();

			return $result ? $result['is_active'] : false;
		}

		public function getUsers() {
			$statement = $this->connection->prepare("SELECT * FROM user");
			$statement->execute();

			$result = $statement->fetchAll(PDO::FETCH_ASSOC);

			return $result ? $result : false;
		}

		public function getMembers($user_id) {
			$statement = $this->connection->prepare("SELECT * FROM user WHERE usergroup != 300 AND id != $user_id");
			$statement->execute();

			$result = $statement->fetchAll(PDO::FETCH_ASSOC);

			return $result ? $result : false;
		}

		public function getActiveUsers() {
			$statement = $this->connection->prepare("SELECT * FROM user WHERE is_active = 1");
			$statement->execute();

			$result = $statement->fetchAll(PDO::FETCH_ASSOC);

			return $result ? $result : false;
		}

		public function getBlockedUsers() {
			$statement = $this->connection->prepare("SELECT * FROM user WHERE is_active = 0");
			$statement->execute();

			$result = $statement->fetchAll(PDO::FETCH_ASSOC);

			return $result ? $result : false;
		}

		// Loging user in
		public function login($email, $password) {
			$statement = $this->connection->prepare("SELECT * FROM user WHERE email = :email AND password = :password AND is_active = 1");
			$statement->execute(array("email"=>$email, "password"=>$password));

			$result = $statement->fetch();

			// Create SESSION variables for logged in user
			if ($result) {
				$_SESSION['us3rid'] = $result['id'];
				$_SESSION['us3rgr0up'] = $result['usergroup'];
				$_SESSION['1s@dmin'] = ($result['usergroup'] == 300) ? true : false;
			}

			return $result ? true : false;
		}

		public function countAll() {
			$statement = $this->connection->prepare("SELECT COUNT(*) AS count FROM user");
			$statement->execute();
			$result = $statement->fetch();

			return $result ? $result['count'] : false;
		}

		public function countActive() {
			$statement = $this->connection->prepare("SELECT COUNT(*) AS count FROM user WHERE is_active = 1");
			$statement->execute();
			$result = $statement->fetch();

			return $result ? $result['count'] : false;
		}

		public function online($id) {
            $statement = $this->connection->prepare("UPDATE user SET status = 1 WHERE id = ?");
            $statement->bindValue(1, $id);
            $result = $statement->execute();

            return $result ? true : false;
        }

        public function offline($id) {
            $statement = $this->connection->prepare("UPDATE user SET status = 0 WHERE id = ?");
            $statement->bindValue(1, $id);
            $result = $statement->execute();

            return $result ? true : false;
        }

        public function countBlockedUsers() {
		    $statement = $this->connection->prepare("SELECT COUNT(*) AS count FROM user WHERE is_active = 0");
		    $statement->execute();
            $result = $statement->fetch();
		    return $result ? $result['count'] : false;
        }

        public function updatePassword($user_id) {
        	$statement = $this->connection->prepare("UPDATE user SET password = ? WHERE id = ?");
        	$statement->bindValue(1, $this->password);
        	$statement->bindValue(2, $user_id);
        	$result = $statement->execute();

        	return $result ? true : false;
        }

		// Delete record from table
		public function delete($id) {
			$query = "DELETE FROM user WHERE id = :id";
			$statement = $this->connection->prepare($query);
			$result = $statement->execute(array("id"=>$id));

			return $result ? true : false;
		}

	}